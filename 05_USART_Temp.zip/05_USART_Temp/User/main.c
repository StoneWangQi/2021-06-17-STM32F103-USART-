/**
  ******************************************************************************
  * @file    GPIO/JTAG_Remap/main.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * 
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "PROJ_book.h" 

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
void delay(int x);
void fn_LED_Flash_Init(void);
void fn_usart_show_Init(void);
int main(void)
{ 


      fn_Led_Init();
      //fn_Key_Init();
      fn_LED_Flash_Init();  
      fn_usart_show_Init();
      fn_EXTI_GPIO_Config();
      
      while(1){        
        delay(10000);
        fn_Usart_SendString(_DEBUG_USARTx," : ���ɶ \n");
      }
}

void fn_LED_Flash_Init(void){
  uint16_t  count_Init = 2;
  while(count_Init-->0){
    __LED_Change__;
    fn_Systick_Delay(500,_Systick_ms);
    __LED_Change__;
    fn_Systick_Delay(100,_Systick_ms);
    __LED_Change__;
    fn_Systick_Delay(100,_Systick_ms);
    __LED_Change__;
    fn_Systick_Delay(500,_Systick_ms);
  } 
}

void fn_usart_show_Init(void){
  fn_USART_IO_Config();
  fn_USART_Config();
  fn_Usart_Send_Byte(_DEBUG_USARTx,'T');
  fn_Usart_Send_Byte(_DEBUG_USARTx,'O');
  Usart_SendHalf_32_Word(_DEBUG_USARTx,0xA69B4B7C);
  fn_Usart_SendString(_DEBUG_USARTx," : ���ɶ \n");
}

void delay(int x){
	int y = 0xFFFFF;
	while((x--)>0){
		while((y--)>0){
			__NOP();
			__NOP();
			__NOP();
			__NOP();
			__NOP();
		}
	}
}
/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
